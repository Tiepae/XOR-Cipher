// Welcome to my basic xor encryption/decryption cipher
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <windows.h>

void encryption(char string[])
{
    // this sets the xor cipher key
    char xorString = 'P';

    int length = strlen(string);

    // Loops through the string converting each character
    for(int i = 0; i < length; i++)
    {
      string[i] = string[i] ^ xorString;
      printf("%c",string[i]);
    }
}

int main()
{
    //system("color E");
    // Create user entry variable
    int selection_option = {0};
    char selection_char[20];
    int selection_int = {0};
    // Create a way to print user interface
    do
    {
    printf("\n");
    puts("/////Encryption-Decryption-Program///////");
        puts("1. Encrypt user entry");
        puts("2. decrypt user entry");
        puts("3. Help?");
        puts("4. Exit program");
    puts("/////////////////////////////////////////");
        scanf("%d", &selection_option);
    // Create a switch statement to allow for different user entries
    switch(selection_option){
        // For case 1 prompt user to enter a character of string to encrypt
        case 1:
            puts("Enter a series of characters to encrypt: ");
            scanf("%s", selection_char);
            // Generate output for case 1
            puts("Encrypted string: ");
            encryption(selection_char);
            printf("\n");
            break;
        // For case 2 enter series of integers & symbols to decrypt
        case 2:
            puts("Enter encryption key outputed from case 1 to decrypt: ");
            scanf("%s", selection_char);
            // Generate output for case 2
            puts("Decrypted string: ");
            encryption(selection_char);
            printf("\n");
            break;
        // Created a simple help tab for users stuck
        case 3:
            puts("When encrypting do not use capital letters!");
            puts("When decrypting enter the numbers & symbols.");
            break;
        // Created a way to exit program
        case 4:
            puts("You exited the program!");
            exit(0);
        default:
            puts("Error! Incompatible entry.");
            exit(0);
            break;
    }

    }while(selection_option > 0); // Add while condition exit criteria in here

    return(0);
}